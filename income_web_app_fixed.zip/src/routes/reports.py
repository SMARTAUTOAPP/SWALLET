from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from src.models.transaction import Transaction
from src.models.budget import Budget
from src.models import db
from src.models.ml.financial_predictor import FinancialPredictor
from src.models.ml.smart_recommendation_engine import SmartRecommendationEngine
from datetime import datetime, timedelta
import json
import calendar

reports_bp = Blueprint('reports', __name__)

@reports_bp.route('/reports')
def show_reports():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على المعاملات للمستخدم
    transactions = Transaction.query.filter_by(user_id=user_id).all()
    
    # تحويل المعاملات إلى قواميس لاستخدامها في المحركات الذكية
    transactions_dict = [t.to_dict() for t in transactions]
    
    # تحليل الإنفاق والدخل حسب الفئة
    income_by_category = {}
    expenses_by_category = {}
    
    for transaction in transactions:
        if transaction.amount > 0:  # دخل
            if transaction.category in income_by_category:
                income_by_category[transaction.category] += transaction.amount
            else:
                income_by_category[transaction.category] = transaction.amount
        else:  # مصروف
            if transaction.category in expenses_by_category:
                expenses_by_category[transaction.category] += abs(transaction.amount)
            else:
                expenses_by_category[transaction.category] = abs(transaction.amount)
    
    # تحليل الإنفاق والدخل حسب الشهر
    income_by_month = {}
    expenses_by_month = {}
    
    for transaction in transactions:
        month_year = transaction.date.strftime('%Y-%m')
        month_name = transaction.date.strftime('%B %Y')
        
        if transaction.amount > 0:  # دخل
            if month_name in income_by_month:
                income_by_month[month_name] += transaction.amount
            else:
                income_by_month[month_name] = transaction.amount
        else:  # مصروف
            if month_name in expenses_by_month:
                expenses_by_month[month_name] += abs(transaction.amount)
            else:
                expenses_by_month[month_name] = abs(transaction.amount)
    
    # توليد التنبؤات المالية
    financial_predictor = FinancialPredictor()
    financial_predictor.update_historical_data(transactions_dict)
    
    # التنبؤ بالإنفاق للأشهر الثلاثة القادمة
    future_expenses = financial_predictor.predict_total_spending(3)
    
    # التنبؤ بالدخل للأشهر الثلاثة القادمة (افتراض أن فئة الدخل الرئيسية هي "راتب")
    future_income = financial_predictor.predict_category_spending("راتب", 3)
    
    # الحصول على سيناريوهات متعددة للتنبؤات
    expense_scenarios = financial_predictor.get_prediction_scenarios("مصروفات", 3)
    
    # تحويل البيانات إلى تنسيق JSON للرسوم البيانية
    income_category_chart_data = json.dumps({
        'labels': list(income_by_category.keys()),
        'data': list(income_by_category.values())
    })
    
    expenses_category_chart_data = json.dumps({
        'labels': list(expenses_by_category.keys()),
        'data': list(expenses_by_category.values())
    })
    
    income_month_chart_data = json.dumps({
        'labels': list(income_by_month.keys()),
        'data': list(income_by_month.values())
    })
    
    expenses_month_chart_data = json.dumps({
        'labels': list(expenses_by_month.keys()),
        'data': list(expenses_by_month.values())
    })
    
    # إعداد بيانات التنبؤات للرسوم البيانية
    now = datetime.now()
    future_months = []
    for i in range(1, 4):
        future_date = now + timedelta(days=30 * i)
        future_months.append(future_date.strftime('%B %Y'))
    
    prediction_chart_data = json.dumps({
        'labels': future_months,
        'income': future_income,
        'expenses': future_expenses,
        'optimistic': expense_scenarios.get('متفائل', [0, 0, 0]),
        'pessimistic': expense_scenarios.get('متشائم', [0, 0, 0])
    })
    
    return render_template(
        'reports/index.html',
        income_category_chart_data=income_category_chart_data,
        expenses_category_chart_data=expenses_category_chart_data,
        income_month_chart_data=income_month_chart_data,
        expenses_month_chart_data=expenses_month_chart_data,
        prediction_chart_data=prediction_chart_data,
        total_income=sum(income_by_category.values()),
        total_expenses=sum(expenses_by_category.values())
    )
