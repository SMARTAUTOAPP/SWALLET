from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from src.models.transaction import Transaction
from src.models.category import Category
from src.models import db
from datetime import datetime

transactions_bp = Blueprint('transactions', __name__)

@transactions_bp.route('/transactions')
def list_transactions():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على المعاملات مرتبة حسب التاريخ (الأحدث أولاً)
    transactions = Transaction.query.filter_by(user_id=user_id).order_by(Transaction.date.desc()).all()
    
    # الحصول على الفئات للمستخدم
    categories = Category.query.filter_by(user_id=user_id).all()
    
    return render_template(
        'transactions/list.html',
        transactions=transactions,
        categories=categories
    )

@transactions_bp.route('/transactions/add', methods=['GET', 'POST'])
def add_transaction():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على الفئات للمستخدم
    categories = Category.query.filter_by(user_id=user_id).all()
    
    if request.method == 'POST':
        amount = float(request.form.get('amount'))
        description = request.form.get('description')
        category = request.form.get('category')
        transaction_type = request.form.get('transaction_type')
        date_str = request.form.get('date')
        
        # تحويل المبلغ إلى سالب إذا كان مصروفاً
        if transaction_type == 'expense':
            amount = -abs(amount)
        
        # تحويل التاريخ من النص إلى كائن datetime
        date = datetime.strptime(date_str, '%Y-%m-%d') if date_str else datetime.now()
        
        # إنشاء معاملة جديدة
        new_transaction = Transaction(
            amount=amount,
            description=description,
            category=category,
            transaction_type=transaction_type,
            user_id=user_id,
            date=date
        )
        
        db.session.add(new_transaction)
        db.session.commit()
        
        flash('تمت إضافة المعاملة بنجاح!', 'success')
        return redirect(url_for('transactions.list_transactions'))
    
    return render_template(
        'transactions/add.html',
        categories=categories
    )

@transactions_bp.route('/transactions/edit/<int:id>', methods=['GET', 'POST'])
def edit_transaction(id):
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على المعاملة المطلوبة
    transaction = Transaction.query.filter_by(id=id, user_id=user_id).first_or_404()
    
    # الحصول على الفئات للمستخدم
    categories = Category.query.filter_by(user_id=user_id).all()
    
    if request.method == 'POST':
        amount = float(request.form.get('amount'))
        description = request.form.get('description')
        category = request.form.get('category')
        transaction_type = request.form.get('transaction_type')
        date_str = request.form.get('date')
        
        # تحويل المبلغ إلى سالب إذا كان مصروفاً
        if transaction_type == 'expense':
            amount = -abs(amount)
        else:
            amount = abs(amount)
        
        # تحويل التاريخ من النص إلى كائن datetime
        date = datetime.strptime(date_str, '%Y-%m-%d') if date_str else datetime.now()
        
        # تحديث المعاملة
        transaction.amount = amount
        transaction.description = description
        transaction.category = category
        transaction.transaction_type = transaction_type
        transaction.date = date
        
        db.session.commit()
        
        flash('تم تحديث المعاملة بنجاح!', 'success')
        return redirect(url_for('transactions.list_transactions'))
    
    return render_template(
        'transactions/edit.html',
        transaction=transaction,
        categories=categories
    )

@transactions_bp.route('/transactions/delete/<int:id>', methods=['POST'])
def delete_transaction(id):
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على المعاملة المطلوبة
    transaction = Transaction.query.filter_by(id=id, user_id=user_id).first_or_404()
    
    db.session.delete(transaction)
    db.session.commit()
    
    flash('تم حذف المعاملة بنجاح!', 'success')
    return redirect(url_for('transactions.list_transactions'))
