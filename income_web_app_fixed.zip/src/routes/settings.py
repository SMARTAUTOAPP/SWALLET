from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from src.models.budget import Budget
from src.models.category import Category
from src.models import db
from src.models.ml.smart_budget_assistant import SmartBudgetAssistant
from datetime import datetime

settings_bp = Blueprint('settings', __name__)

@settings_bp.route('/settings')
def show_settings():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على الفئات للمستخدم
    categories = Category.query.filter_by(user_id=user_id).all()
    
    # الحصول على الميزانيات للمستخدم
    budgets = Budget.query.filter_by(user_id=user_id).all()
    
    return render_template(
        'settings/index.html',
        categories=categories,
        budgets=budgets
    )

@settings_bp.route('/settings/categories/add', methods=['POST'])
def add_category():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    name = request.form.get('name')
    icon = request.form.get('icon')
    color = request.form.get('color')
    
    # إنشاء فئة جديدة
    new_category = Category(name=name, user_id=user_id, icon=icon, color=color)
    
    db.session.add(new_category)
    db.session.commit()
    
    flash('تمت إضافة الفئة بنجاح!', 'success')
    return redirect(url_for('settings.show_settings'))

@settings_bp.route('/settings/categories/edit/<int:id>', methods=['POST'])
def edit_category(id):
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على الفئة المطلوبة
    category = Category.query.filter_by(id=id, user_id=user_id).first_or_404()
    
    name = request.form.get('name')
    icon = request.form.get('icon')
    color = request.form.get('color')
    
    # تحديث الفئة
    category.name = name
    category.icon = icon
    category.color = color
    
    db.session.commit()
    
    flash('تم تحديث الفئة بنجاح!', 'success')
    return redirect(url_for('settings.show_settings'))

@settings_bp.route('/settings/categories/delete/<int:id>', methods=['POST'])
def delete_category(id):
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على الفئة المطلوبة
    category = Category.query.filter_by(id=id, user_id=user_id).first_or_404()
    
    db.session.delete(category)
    db.session.commit()
    
    flash('تم حذف الفئة بنجاح!', 'success')
    return redirect(url_for('settings.show_settings'))

@settings_bp.route('/settings/budgets/add', methods=['POST'])
def add_budget():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    category = request.form.get('category')
    amount = float(request.form.get('amount'))
    start_date_str = request.form.get('start_date')
    end_date_str = request.form.get('end_date')
    
    # تحويل التواريخ من النص إلى كائنات datetime
    start_date = datetime.strptime(start_date_str, '%Y-%m-%d') if start_date_str else datetime.now()
    end_date = datetime.strptime(end_date_str, '%Y-%m-%d') if end_date_str else None
    
    # إنشاء ميزانية جديدة
    new_budget = Budget(
        category=category,
        amount=amount,
        user_id=user_id,
        start_date=start_date,
        end_date=end_date
    )
    
    db.session.add(new_budget)
    db.session.commit()
    
    flash('تمت إضافة الميزانية بنجاح!', 'success')
    return redirect(url_for('settings.show_settings'))

@settings_bp.route('/settings/budgets/edit/<int:id>', methods=['POST'])
def edit_budget(id):
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على الميزانية المطلوبة
    budget = Budget.query.filter_by(id=id, user_id=user_id).first_or_404()
    
    category = request.form.get('category')
    amount = float(request.form.get('amount'))
    start_date_str = request.form.get('start_date')
    end_date_str = request.form.get('end_date')
    
    # تحويل التواريخ من النص إلى كائنات datetime
    start_date = datetime.strptime(start_date_str, '%Y-%m-%d') if start_date_str else datetime.now()
    end_date = datetime.strptime(end_date_str, '%Y-%m-%d') if end_date_str else None
    
    # تحديث الميزانية
    budget.category = category
    budget.amount = amount
    budget.start_date = start_date
    budget.end_date = end_date
    
    db.session.commit()
    
    flash('تم تحديث الميزانية بنجاح!', 'success')
    return redirect(url_for('settings.show_settings'))

@settings_bp.route('/settings/budgets/delete/<int:id>', methods=['POST'])
def delete_budget(id):
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على الميزانية المطلوبة
    budget = Budget.query.filter_by(id=id, user_id=user_id).first_or_404()
    
    db.session.delete(budget)
    db.session.commit()
    
    flash('تم حذف الميزانية بنجاح!', 'success')
    return redirect(url_for('settings.show_settings'))

@settings_bp.route('/settings/smart-budgets')
def smart_budgets():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على المعاملات والميزانيات للمستخدم
    from src.models.transaction import Transaction
    transactions = Transaction.query.filter_by(user_id=user_id).all()
    budgets = Budget.query.filter_by(user_id=user_id).all()
    
    # تحويل المعاملات والميزانيات إلى قواميس لاستخدامها في المساعد الذكي
    transactions_dict = [t.to_dict() for t in transactions]
    budgets_dict = [b.to_dict() for b in budgets]
    
    # توليد اقتراحات الميزانية الذكية
    budget_assistant = SmartBudgetAssistant()
    suggestions = budget_assistant.suggest_smart_budgets(transactions_dict, budgets_dict)
    
    return render_template(
        'settings/smart_budgets.html',
        suggestions=[s.to_dict() for s in suggestions],
        current_budgets=budgets
    )
