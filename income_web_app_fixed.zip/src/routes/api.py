from flask import Blueprint, jsonify, request, session
from src.models.transaction import Transaction
from src.models.budget import Budget
from src.models import db
from src.models.ml.transaction_classifier import TransactionClassifier
from src.models.ml.financial_predictor import FinancialPredictor
from src.models.ml.smart_recommendation_engine import SmartRecommendationEngine
from src.models.ml.smart_budget_assistant import SmartBudgetAssistant
from datetime import datetime

api_bp = Blueprint('api', __name__)

@api_bp.route('/classify-transaction', methods=['POST'])
def classify_transaction():
    if 'user_id' not in session:
        return jsonify({'error': 'غير مصرح'}), 401
    
    user_id = session['user_id']
    data = request.get_json()
    
    description = data.get('description', '')
    amount = float(data.get('amount', 0))
    
    # الحصول على المعاملات السابقة للتدريب
    transactions = Transaction.query.filter_by(user_id=user_id).all()
    transactions_dict = [t.to_dict() for t in transactions]
    
    # إنشاء وتدريب المصنف
    classifier = TransactionClassifier()
    classifier.train(transactions_dict)
    
    # تصنيف المعاملة الجديدة
    category = classifier.classify(description, amount)
    
    # الحصول على أفضل الفئات المحتملة
    top_categories = classifier.get_top_categories(description, amount, 3)
    
    return jsonify({
        'category': category,
        'top_categories': top_categories
    })

@api_bp.route('/get-recommendations', methods=['GET'])
def get_recommendations():
    if 'user_id' not in session:
        return jsonify({'error': 'غير مصرح'}), 401
    
    user_id = session['user_id']
    
    # الحصول على المعاملات والميزانيات
    transactions = Transaction.query.filter_by(user_id=user_id).all()
    budgets = Budget.query.filter_by(user_id=user_id).all()
    
    transactions_dict = [t.to_dict() for t in transactions]
    budgets_dict = [b.to_dict() for b in budgets]
    
    # إنشاء محرك التوصيات وتوليد التوصيات
    recommendation_engine = SmartRecommendationEngine()
    recommendations = recommendation_engine.generate_recommendations(transactions_dict, budgets_dict)
    top_recommendations = recommendation_engine.get_top_recommendations(recommendations, 5)
    
    return jsonify({
        'recommendations': [r.to_dict() for r in top_recommendations]
    })

@api_bp.route('/get-financial-predictions', methods=['GET'])
def get_financial_predictions():
    if 'user_id' not in session:
        return jsonify({'error': 'غير مصرح'}), 401
    
    user_id = session['user_id']
    months = int(request.args.get('months', 3))
    
    # الحصول على المعاملات
    transactions = Transaction.query.filter_by(user_id=user_id).all()
    transactions_dict = [t.to_dict() for t in transactions]
    
    # إنشاء محلل التنبؤات وتحديث البيانات التاريخية
    predictor = FinancialPredictor()
    predictor.update_historical_data(transactions_dict)
    
    # التنبؤ بالإنفاق والدخل
    total_spending = predictor.predict_total_spending(months)
    income_predictions = predictor.predict_category_spending("راتب", months)
    
    # الحصول على سيناريوهات متعددة
    expense_scenarios = predictor.get_prediction_scenarios("مصروفات", months)
    
    return jsonify({
        'total_spending': total_spending,
        'income_predictions': income_predictions,
        'expense_scenarios': expense_scenarios
    })

@api_bp.route('/get-budget-suggestions', methods=['GET'])
def get_budget_suggestions():
    if 'user_id' not in session:
        return jsonify({'error': 'غير مصرح'}), 401
    
    user_id = session['user_id']
    
    # الحصول على المعاملات والميزانيات
    transactions = Transaction.query.filter_by(user_id=user_id).all()
    budgets = Budget.query.filter_by(user_id=user_id).all()
    
    transactions_dict = [t.to_dict() for t in transactions]
    budgets_dict = [b.to_dict() for b in budgets]
    
    # إنشاء مساعد الميزانية وتوليد الاقتراحات
    budget_assistant = SmartBudgetAssistant()
    suggestions = budget_assistant.suggest_smart_budgets(transactions_dict, budgets_dict)
    
    return jsonify({
        'suggestions': [s.to_dict() for s in suggestions]
    })

@api_bp.route('/get-budget-alerts', methods=['GET'])
def get_budget_alerts():
    if 'user_id' not in session:
        return jsonify({'error': 'غير مصرح'}), 401
    
    user_id = session['user_id']
    
    # الحصول على المعاملات والميزانيات
    now = datetime.now()
    start_of_month = datetime(now.year, now.month, 1)
    
    transactions = Transaction.query.filter(
        Transaction.user_id == user_id,
        Transaction.date >= start_of_month
    ).all()
    
    budgets = Budget.query.filter_by(user_id=user_id).all()
    
    transactions_dict = [t.to_dict() for t in transactions]
    budgets_dict = [b.to_dict() for b in budgets]
    
    # إنشاء مساعد الميزانية وتوليد التنبيهات
    budget_assistant = SmartBudgetAssistant()
    alerts = budget_assistant.generate_budget_alerts(transactions_dict, budgets_dict)
    
    return jsonify({
        'alerts': [a.to_dict() for a in alerts]
    })
