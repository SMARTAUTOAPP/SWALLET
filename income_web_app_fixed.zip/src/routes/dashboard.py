from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from src.models.transaction import Transaction
from src.models.category import Category
from src.models.budget import Budget
from src.models import db
from src.models.ml.transaction_classifier import TransactionClassifier
from src.models.ml.financial_predictor import FinancialPredictor
from src.models.ml.smart_recommendation_engine import SmartRecommendationEngine
from src.models.ml.smart_budget_assistant import SmartBudgetAssistant
from datetime import datetime, timedelta
import json

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/home')
def home():
    if 'user_id' not in session:
        return redirect(url_for('auth.login'))
    
    user_id = session['user_id']
    
    # الحصول على المعاملات الأخيرة
    recent_transactions = Transaction.query.filter_by(user_id=user_id).order_by(Transaction.date.desc()).limit(5).all()
    
    # الحصول على الميزانيات الحالية
    current_budgets = Budget.query.filter_by(user_id=user_id).all()
    
    # حساب إجمالي الدخل والمصروفات للشهر الحالي
    now = datetime.now()
    start_of_month = datetime(now.year, now.month, 1)
    
    monthly_transactions = Transaction.query.filter(
        Transaction.user_id == user_id,
        Transaction.date >= start_of_month
    ).all()
    
    total_income = sum(t.amount for t in monthly_transactions if t.amount > 0)
    total_expenses = sum(abs(t.amount) for t in monthly_transactions if t.amount < 0)
    
    # تحضير البيانات للرسوم البيانية
    income_by_category = {}
    expenses_by_category = {}
    
    for transaction in monthly_transactions:
        if transaction.amount > 0:  # دخل
            if transaction.category in income_by_category:
                income_by_category[transaction.category] += transaction.amount
            else:
                income_by_category[transaction.category] = transaction.amount
        else:  # مصروف
            if transaction.category in expenses_by_category:
                expenses_by_category[transaction.category] += abs(transaction.amount)
            else:
                expenses_by_category[transaction.category] = abs(transaction.amount)
    
    # توليد التوصيات الذكية
    recommendation_engine = SmartRecommendationEngine()
    
    # تحويل المعاملات والميزانيات إلى قواميس لاستخدامها في المحرك الذكي
    transactions_dict = [t.to_dict() for t in monthly_transactions]
    budgets_dict = [b.to_dict() for b in current_budgets]
    
    recommendations = recommendation_engine.generate_recommendations(transactions_dict, budgets_dict)
    top_recommendations = recommendation_engine.get_top_recommendations(recommendations, 3)
    
    # توليد تنبيهات الميزانية
    budget_assistant = SmartBudgetAssistant()
    budget_alerts = budget_assistant.generate_budget_alerts(transactions_dict, budgets_dict)
    
    # تحويل البيانات إلى تنسيق JSON للرسوم البيانية
    income_chart_data = json.dumps({
        'labels': list(income_by_category.keys()),
        'data': list(income_by_category.values())
    })
    
    expenses_chart_data = json.dumps({
        'labels': list(expenses_by_category.keys()),
        'data': list(expenses_by_category.values())
    })
    
    return render_template(
        'dashboard/home.html',
        recent_transactions=recent_transactions,
        current_budgets=current_budgets,
        total_income=total_income,
        total_expenses=total_expenses,
        income_chart_data=income_chart_data,
        expenses_chart_data=expenses_chart_data,
        recommendations=[r.to_dict() for r in top_recommendations],
        budget_alerts=[a.to_dict() for a in budget_alerts]
    )
