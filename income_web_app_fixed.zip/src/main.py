import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from flask import Flask, render_template, jsonify, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from src.models import init_app, db
import os
from dotenv import load_dotenv
import logging

# تكوين التسجيل
logging.basicConfig(level=logging.DEBUG)

# تحميل متغيرات البيئة من ملف .env إذا كان موجوداً
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', os.urandom(24))

# تكوين قاعدة البيانات حسب بيئة التشغيل
if os.environ.get('FLASK_ENV') == 'production':
    # استخدام قاعدة بيانات SQLite في بيئة الإنتاج (للتبسيط)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///income_manager.db'
    app.config['DEBUG'] = True  # تفعيل وضع التصحيح مؤقتاً لتشخيص المشكلة
else:
    # استخدام SQLite في بيئة التطوير
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///income_manager.db'
    app.config['DEBUG'] = True

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# تهيئة قاعدة البيانات
try:
    init_app(app)
    app.logger.info("تم تهيئة قاعدة البيانات بنجاح")
except Exception as e:
    app.logger.error(f"خطأ في تهيئة قاعدة البيانات: {str(e)}")

# استيراد المسارات
try:
    from src.routes.auth import auth_bp
    from src.routes.dashboard import dashboard_bp
    from src.routes.transactions import transactions_bp
    from src.routes.reports import reports_bp
    from src.routes.settings import settings_bp
    from src.routes.api import api_bp
    
    # تسجيل المسارات
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(transactions_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(settings_bp)
    app.register_blueprint(api_bp, url_prefix='/api')
    
    app.logger.info("تم تسجيل جميع المسارات بنجاح")
except Exception as e:
    app.logger.error(f"خطأ في استيراد أو تسجيل المسارات: {str(e)}")

@app.route('/')
def index():
    try:
        if 'user_id' in session:
            return redirect(url_for('dashboard.home'))
        return redirect(url_for('auth.login'))
    except Exception as e:
        app.logger.error(f"خطأ في المسار الرئيسي: {str(e)}")
        return render_template('errors/500.html', error=str(e)), 500

@app.route('/debug')
def debug_info():
    """مسار للتشخيص يعرض معلومات عن البيئة والتكوين"""
    debug_data = {
        "python_version": sys.version,
        "flask_version": Flask.__version__,
        "database_uri": app.config['SQLALCHEMY_DATABASE_URI'],
        "debug_mode": app.config['DEBUG'],
        "blueprints": list(app.blueprints.keys()),
        "routes": [str(rule) for rule in app.url_map.iter_rules()],
        "environment": dict(os.environ)
    }
    return jsonify(debug_data)

@app.errorhandler(404)
def page_not_found(e):
    app.logger.warning(f"صفحة غير موجودة: {request.path}")
    return render_template('errors/404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    app.logger.error(f"خطأ داخلي في الخادم: {str(e)}")
    return render_template('errors/500.html', error=str(e)), 500

if __name__ == '__main__':
    # تشغيل التطبيق على جميع الواجهات في بيئة التطوير
    app.run(debug=app.config['DEBUG'], host='0.0.0.0')
