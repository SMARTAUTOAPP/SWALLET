from datetime import datetime
from src.models import db

class Transaction(db.Model):
    """
    نموذج المعاملة المالية
    يمثل معاملة مالية واحدة (دخل أو مصروف)
    """
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    transaction_type = db.Column(db.String(20), nullable=False)  # دخل أو مصروف
    date = db.Column(db.DateTime, default=datetime.now)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    def __init__(self, amount, description, category, transaction_type, user_id, date=None):
        self.amount = amount
        self.description = description
        self.category = category
        self.transaction_type = transaction_type
        self.user_id = user_id
        if date:
            self.date = date
    
    def to_dict(self):
        """
        تحويل المعاملة إلى قاموس
        """
        return {
            'id': self.id,
            'amount': self.amount,
            'description': self.description,
            'category': self.category,
            'transaction_type': self.transaction_type,
            'date': self.date.strftime('%Y-%m-%d %H:%M:%S'),
            'user_id': self.user_id
        }
