from datetime import datetime
from src.models import db

class Budget(db.Model):
    """
    نموذج الميزانية
    يمثل ميزانية لفئة معينة خلال فترة زمنية محددة
    """
    __tablename__ = 'budgets'
    
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    start_date = db.Column(db.DateTime, default=datetime.now)
    end_date = db.Column(db.DateTime, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    def __init__(self, category, amount, user_id, start_date=None, end_date=None):
        self.category = category
        self.amount = amount
        self.user_id = user_id
        if start_date:
            self.start_date = start_date
        if end_date:
            self.end_date = end_date
    
    def to_dict(self):
        """
        تحويل الميزانية إلى قاموس
        """
        return {
            'id': self.id,
            'category': self.category,
            'amount': self.amount,
            'start_date': self.start_date.strftime('%Y-%m-%d %H:%M:%S'),
            'end_date': self.end_date.strftime('%Y-%m-%d %H:%M:%S') if self.end_date else None,
            'user_id': self.user_id
        }
