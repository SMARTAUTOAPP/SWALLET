from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def init_app(app):
    db.init_app(app)
    
    # استيراد النماذج بعد تهيئة قاعدة البيانات
    from src.models.user import User
    from src.models.transaction import Transaction
    from src.models.category import Category
    from src.models.budget import Budget
    
    # إنشاء جميع الجداول
    with app.app_context():
        db.create_all()
