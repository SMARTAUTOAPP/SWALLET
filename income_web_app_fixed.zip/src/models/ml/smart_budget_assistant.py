from enum import Enum
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from collections import defaultdict
import math
import calendar

class AlertType(Enum):
    """
    أنواع تنبيهات الميزانية
    """
    APPROACHING_LIMIT = "اقتراب من حد الميزانية"
    EXCEEDED_LIMIT = "تجاوز حد الميزانية"
    UNUSUAL_SPENDING = "إنفاق غير معتاد"

class BudgetSuggestion:
    """
    فئة لتمثيل اقتراح ميزانية
    """
    def __init__(self, category: str, suggested_amount: float, reason: str, confidence: float):
        self.category = category
        self.suggested_amount = suggested_amount
        self.reason = reason
        self.confidence = confidence
    
    def to_dict(self) -> dict:
        """
        تحويل اقتراح الميزانية إلى قاموس
        """
        return {
            'category': self.category,
            'suggested_amount': self.suggested_amount,
            'reason': self.reason,
            'confidence': self.confidence
        }

class BudgetAlert:
    """
    فئة لتمثيل تنبيه ميزانية
    """
    def __init__(self, category: str, alert_type: AlertType, current_spending: float, 
                budget_limit: float, message: str):
        self.category = category
        self.type = alert_type
        self.current_spending = current_spending
        self.budget_limit = budget_limit
        self.percentage = budget_limit > 0 and current_spending / budget_limit or 0
        self.message = message
    
    def to_dict(self) -> dict:
        """
        تحويل تنبيه الميزانية إلى قاموس
        """
        return {
            'category': self.category,
            'type': self.type.value,
            'current_spending': self.current_spending,
            'budget_limit': self.budget_limit,
            'percentage': self.percentage,
            'message': self.message
        }

class SmartBudgetAssistant:
    """
    المساعد الذكي للميزانية
    يساعد في إنشاء وإدارة الميزانيات بشكل ذكي بناءً على أنماط الإنفاق
    """
    
    def __init__(self):
        pass
    
    def suggest_smart_budgets(self, transactions: List[dict], current_budgets: List[dict]) -> List[BudgetSuggestion]:
        """
        اقتراح ميزانيات ذكية بناءً على أنماط الإنفاق التاريخية
        
        Args:
            transactions: قائمة المعاملات التاريخية
            current_budgets: الميزانيات الحالية (إن وجدت)
            
        Returns:
            قائمة باقتراحات الميزانية
        """
        print("توليد اقتراحات الميزانية الذكية...")
        
        suggestions = []
        
        # تحليل الإنفاق حسب الفئة والشهر
        category_monthly_spending = self._analyze_category_monthly_spending(transactions)
        
        # الحصول على الميزانيات الحالية كخريطة
        current_budget_map = {}
        for budget in current_budgets:
            current_budget_map[budget['category']] = float(budget['amount'])
        
        # لكل فئة، حساب متوسط الإنفاق الشهري واقتراح ميزانية
        for category, monthly_spending in category_monthly_spending.items():
            if len(monthly_spending) < 2:
                continue  # نحتاج على الأقل إلى شهرين من البيانات
            
            # حساب متوسط الإنفاق الشهري
            total_spending = sum(monthly_spending.values())
            average_monthly_spending = total_spending / len(monthly_spending)
            
            # حساب الانحراف المعياري للإنفاق الشهري
            sum_squared_diff = sum((amount - average_monthly_spending) ** 2 for amount in monthly_spending.values())
            std_dev = math.sqrt(sum_squared_diff / len(monthly_spending))
            
            # اقتراح ميزانية بناءً على متوسط الإنفاق + هامش أمان
            suggested_budget = average_monthly_spending + (0.1 * average_monthly_spending)
            
            # تعديل الاقتراح إذا كان الإنفاق متقلباً
            if std_dev > 0.2 * average_monthly_spending:
                suggested_budget += std_dev * 0.5  # إضافة هامش أمان إضافي للفئات ذات الإنفاق المتقلب
            
            # تقريب الميزانية المقترحة إلى أقرب 10
            suggested_budget = math.ceil(suggested_budget / 10) * 10
            
            # مقارنة مع الميزانية الحالية (إن وجدت)
            reason = ""
            confidence = 0.8 - (std_dev / average_monthly_spending)  # ثقة أقل مع تقلب أكبر
            confidence = max(0.5, min(0.9, confidence))  # تقييد الثقة بين 0.5 و 0.9
            
            if category in current_budget_map:
                current_budget = current_budget_map[category]
                difference = suggested_budget - current_budget
                
                if abs(difference) < 0.1 * current_budget:
                    # الميزانية الحالية قريبة من الاقتراح، لا داعي للتغيير
                    continue
                elif difference > 0:
                    reason = "بناءً على أنماط الإنفاق الأخيرة، ميزانيتك الحالية قد تكون غير كافية"
                else:
                    reason = "يمكنك تقليل ميزانيتك الحالية بناءً على أنماط الإنفاق الفعلية"
            else:
                reason = "اقتراح ميزانية جديدة بناءً على متوسط الإنفاق التاريخي"
            
            suggestions.append(BudgetSuggestion(category, suggested_budget, reason, confidence))
        
        print(f"تم توليد {len(suggestions)} اقتراحات للميزانية")
        
        return suggestions
    
    def _analyze_category_monthly_spending(self, transactions: List[dict]) -> Dict[str, Dict[str, float]]:
        """
        تحليل الإنفاق الشهري حسب الفئة
        
        Args:
            transactions: قائمة المعاملات
            
        Returns:
            خريطة ثنائية تحتوي على الإنفاق الشهري لكل فئة
        """
        category_monthly_spending = defaultdict(lambda: defaultdict(float))
        
        for transaction in transactions:
            amount = float(transaction['amount'])
            if amount < 0:  # معاملات الإنفاق فقط
                category = transaction['category']
                date_str = transaction['date']
                amount_abs = abs(amount)
                
                # تحديد الشهر والسنة
                date = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
                month_year = f"{date.year}-{date.month}"
                
                # إضافة المبلغ إلى المجموع الشهري للفئة
                category_monthly_spending[category][month_year] += amount_abs
        
        return category_monthly_spending
    
    def generate_budget_alerts(self, transactions: List[dict], budgets: List[dict]) -> List[BudgetAlert]:
        """
        إنشاء تنبيهات الميزانية بناءً على الإنفاق الحالي
        
        Args:
            transactions: قائمة المعاملات الحالية (للشهر الحالي)
            budgets: قائمة الميزانيات
            
        Returns:
            قائمة بتنبيهات الميزانية
        """
        print("توليد تنبيهات الميزانية...")
        
        alerts = []
        
        # حساب الإنفاق الحالي لكل فئة
        category_current_spending = defaultdict(float)
        
        for transaction in transactions:
            amount = float(transaction['amount'])
            if amount < 0:  # معاملات الإنفاق فقط
                category = transaction['category']
                amount_abs = abs(amount)
                category_current_spending[category] += amount_abs
        
        # إنشاء تنبيهات بناءً على مقارنة الإنفاق الحالي مع الميزانيات
        for budget in budgets:
            category = budget['category']
            budget_limit = float(budget['amount'])
            
            if category in category_current_spending:
                current_spending = category_current_spending[category]
                percentage = current_spending / budget_limit if budget_limit > 0 else 0
                
                if percentage >= 1.0:
                    # تجاوز حد الميزانية
                    alerts.append(BudgetAlert(
                        category,
                        AlertType.EXCEEDED_LIMIT,
                        current_spending,
                        budget_limit,
                        f"لقد تجاوزت ميزانيتك لفئة {category} بنسبة {((percentage - 1.0) * 100):.1f}%"
                    ))
                elif percentage >= 0.8:
                    # اقتراب من حد الميزانية
                    alerts.append(BudgetAlert(
                        category,
                        AlertType.APPROACHING_LIMIT,
                        current_spending,
                        budget_limit,
                        f"أنت تقترب من حد ميزانيتك لفئة {category} ({percentage * 100:.1f}%)"
                    ))
                
                # اكتشاف الإنفاق غير المعتاد
                now = datetime.now()
                current_day = now.day
                days_in_month = calendar.monthrange(now.year, now.month)[1]
                
                if current_day < (days_in_month / 2) and percentage > 0.7:
                    alerts.append(BudgetAlert(
                        category,
                        AlertType.UNUSUAL_SPENDING,
                        current_spending,
                        budget_limit,
                        f"إنفاق غير معتاد: لقد أنفقت {percentage * 100:.1f}% من ميزانيتك لفئة {category} في النصف الأول من الشهر"
                    ))
        
        print(f"تم توليد {len(alerts)} تنبيهات للميزانية")
        
        return alerts
    
    def analyze_budget_performance(self, historical_transactions: List[dict], 
                                  historical_budgets: List[dict]) -> Dict[str, List[float]]:
        """
        تحليل أداء الميزانية للفترات السابقة
        
        Args:
            historical_transactions: قائمة المعاملات التاريخية
            historical_budgets: قائمة الميزانيات التاريخية
            
        Returns:
            خريطة تحتوي على أداء الميزانية لكل فئة
        """
        category_performance = defaultdict(list)
        
        # تنظيم المعاملات والميزانيات حسب الشهر والفئة
        month_category_spending = defaultdict(lambda: defaultdict(float))
        month_category_budget = defaultdict(lambda: defaultdict(float))
        
        # تحليل الإنفاق الشهري لكل فئة
        for transaction in historical_transactions:
            amount = float(transaction['amount'])
            if amount < 0:  # معاملات الإنفاق فقط
                category = transaction['category']
                date_str = transaction['date']
                amount_abs = abs(amount)
                
                # تحديد الشهر والسنة
                date = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
                month_year = f"{date.year}-{date.month}"
                
                # إضافة المبلغ إلى المجموع الشهري للفئة
                month_category_spending[month_year][category] += amount_abs
        
        # تنظيم الميزانيات حسب الشهر والفئة
        for budget in historical_budgets:
            category = budget['category']
            start_date_str = budget.get('start_date', '')
            amount = float(budget['amount'])
            
            if start_date_str:
                # تحديد الشهر والسنة
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d %H:%M:%S')
                month_year = f"{start_date.year}-{start_date.month}"
                
                # تخزين مبلغ الميزانية للفئة والشهر
                month_category_budget[month_year][category] = amount
        
        # حساب أداء الميزانية (الإنفاق / الميزانية) لكل فئة وشهر
        for month_year, category_spending in month_category_spending.items():
            if month_year not in month_category_budget:
                continue
            
            category_budget = month_category_budget[month_year]
            
            for category, spending in category_spending.items():
                if category not in category_budget or category_budget[category] <= 0:
                    continue
                
                budget = category_budget[category]
                performance = spending / budget  # نسبة استخدام الميزانية
                category_performance[category].append(performance)
        
        return category_performance
    
    def provide_budget_improvement_tips(self, budget_performance: Dict[str, List[float]]) -> List[str]:
        """
        تقديم توصيات لتحسين أداء الميزانية
        
        Args:
            budget_performance: خريطة أداء الميزانية
            
        Returns:
            قائمة بالتوصيات لتحسين الميزانية
        """
        tips = []
        
        for category, performances in budget_performance.items():
            if len(performances) < 3:
                continue  # نحتاج إلى بيانات كافية للتحليل
            
            # حساب متوسط الأداء
            avg_performance = sum(performances) / len(performances)
            
            # تحليل اتجاه الأداء (هل يتحسن أم يتدهور؟)
            recent_performances = performances[-3:]  # آخر 3 أشهر
            recent_avg = sum(recent_performances) / len(recent_performances)
            
            if avg_performance > 1.1:  # تجاوز الميزانية بشكل مستمر
                if recent_avg > avg_performance:  # الوضع يزداد سوءاً
                    tips.append(f"فئة {category}: أنت تتجاوز ميزانيتك باستمرار والوضع يزداد سوءاً. فكر في زيادة الميزانية أو تقليل الإنفاق بشكل كبير.")
                else:  # الوضع يتحسن ولكن لا يزال فوق الميزانية
                    tips.append(f"فئة {category}: رغم التحسن، لا تزال تتجاوز ميزانيتك. استمر في جهودك لتقليل الإنفاق.")
            elif avg_performance > 0.95:  # قريب من الميزانية
                tips.append(f"فئة {category}: أنت تستخدم معظم ميزانيتك بشكل منتظم. هذا جيد للتخطيط المالي.")
            elif avg_performance < 0.7:  # استخدام أقل من الميزانية
                tips.append(f"فئة {category}: أنت تستخدم أقل من 70% من ميزانيتك. يمكنك تقليل الميزانية وتخصيص الفائض لفئات أخرى.")
        
        return tips
