import math
import calendar
from datetime import datetime
from typing import List, Dict, Optional
from collections import defaultdict

class FinancialPredictor:
    """
    محلل التنبؤات المالية
    يستخدم نماذج السلاسل الزمنية للتنبؤ بالإنفاق والدخل المستقبلي
    """
    
    # معاملات نموذج المتوسط المتحرك الموزون أسياً (Exponentially Weighted Moving Average)
    ALPHA = 0.3  # معامل التمهيد (أقل = تمهيد أكثر)
    
    def __init__(self):
        # خرائط لتخزين بيانات التنبؤ لكل فئة
        self.category_historical_data: Dict[str, List[float]] = {}
        self.category_last_predictions: Dict[str, float] = {}
    
    def update_historical_data(self, transactions: List[dict]) -> None:
        """
        تحديث البيانات التاريخية بمعاملات جديدة
        
        Args:
            transactions: قائمة المعاملات
        """
        print("تحديث البيانات التاريخية للتنبؤات المالية...")
        
        # تنظيم المعاملات حسب الفئة والشهر
        category_monthly_totals: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(float))
        
        for transaction in transactions:
            category = transaction['category']
            date_str = transaction['date']
            amount = float(transaction['amount'])
            
            # تحديد الشهر والسنة
            date = datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')
            month_year = f"{date.year}-{date.month}"
            
            # إضافة المبلغ إلى المجموع الشهري للفئة
            category_monthly_totals[category][month_year] += amount
        
        # تحويل البيانات الشهرية إلى سلاسل زمنية
        for category, monthly_totals in category_monthly_totals.items():
            time_series_data = []
            
            # ترتيب البيانات زمنياً (تبسيط - في التطبيق الفعلي يجب ترتيب الأشهر)
            for amount in monthly_totals.values():
                time_series_data.append(amount)
            
            self.category_historical_data[category] = time_series_data
        
        print(f"اكتمل تحديث البيانات التاريخية. عدد الفئات: {len(self.category_historical_data)}")
    
    def predict_category_spending(self, category: str, months: int) -> List[float]:
        """
        التنبؤ بالإنفاق المستقبلي لفئة معينة
        
        Args:
            category: الفئة
            months: عدد الأشهر للتنبؤ
            
        Returns:
            قائمة بالقيم المتوقعة للأشهر القادمة
        """
        predictions = []
        
        if category not in self.category_historical_data or not self.category_historical_data[category]:
            print(f"لا توجد بيانات تاريخية كافية للفئة: {category}")
            # إرجاع قيم صفرية إذا لم تتوفر بيانات
            return [0.0] * months
        
        historical_data = self.category_historical_data[category]
        
        # حساب المتوسط المتحرك الموزون أسياً (EWMA) للتنبؤ
        last_value = historical_data[-1]
        last_prediction = self.category_last_predictions.get(category, last_value)
        
        for _ in range(months):
            # التنبؤ التالي هو مزيج من القيمة الأخيرة والتنبؤ السابق
            next_prediction = self.ALPHA * last_value + (1 - self.ALPHA) * last_prediction
            predictions.append(next_prediction)
            
            # تحديث القيم للتنبؤ التالي
            last_prediction = next_prediction
        
        # تخزين آخر تنبؤ للاستخدام في المرة القادمة
        self.category_last_predictions[category] = last_prediction
        
        return predictions
    
    def predict_total_spending(self, months: int) -> List[float]:
        """
        التنبؤ بإجمالي الإنفاق المستقبلي لجميع الفئات
        
        Args:
            months: عدد الأشهر للتنبؤ
            
        Returns:
            قائمة بالقيم المتوقعة للإنفاق الإجمالي
        """
        total_predictions = [0.0] * months
        
        # جمع التنبؤات من جميع فئات الإنفاق
        for category in self.category_historical_data:
            category_predictions = self.predict_category_spending(category, months)
            
            # إضافة تنبؤات الفئة إلى الإجمالي
            for i in range(min(months, len(category_predictions))):
                total_predictions[i] += category_predictions[i]
        
        return total_predictions
    
    def predict_savings(self, income_category: str, months: int) -> List[float]:
        """
        التنبؤ بالمدخرات المستقبلية (الدخل - الإنفاق)
        
        Args:
            income_category: فئة الدخل
            months: عدد الأشهر للتنبؤ
            
        Returns:
            قائمة بالقيم المتوقعة للمدخرات
        """
        income_predictions = self.predict_category_spending(income_category, months)
        expense_predictions = self.predict_total_spending(months)
        savings_predictions = []
        
        # حساب المدخرات المتوقعة (الدخل - الإنفاق)
        for i in range(min(months, len(income_predictions), len(expense_predictions))):
            savings_predictions.append(income_predictions[i] - expense_predictions[i])
        
        return savings_predictions
    
    def evaluate_prediction_accuracy(self, category: str, actual_values: List[float]) -> float:
        """
        تقييم دقة التنبؤات مقابل القيم الفعلية
        
        Args:
            category: الفئة
            actual_values: القيم الفعلية
            
        Returns:
            متوسط الخطأ المطلق (MAE)
        """
        if category not in self.category_historical_data or not self.category_historical_data[category]:
            return float('nan')
        
        predictions = self.predict_category_spending(category, len(actual_values))
        
        total_error = 0.0
        count = min(len(predictions), len(actual_values))
        
        for i in range(count):
            total_error += abs(predictions[i] - actual_values[i])
        
        return total_error / count if count > 0 else float('nan')
    
    def get_prediction_scenarios(self, category: str, months: int) -> Dict[str, List[float]]:
        """
        الحصول على سيناريوهات متعددة للتنبؤات (متفائل، متوسط، متشائم)
        
        Args:
            category: الفئة
            months: عدد الأشهر للتنبؤ
            
        Returns:
            خريطة تحتوي على ثلاثة سيناريوهات للتنبؤ
        """
        scenarios = {}
        
        # السيناريو المتوسط (التنبؤ العادي)
        baseline_predictions = self.predict_category_spending(category, months)
        scenarios["متوسط"] = baseline_predictions
        
        # السيناريو المتفائل (أقل بنسبة 10%)
        optimistic_predictions = [prediction * 0.9 for prediction in baseline_predictions]
        scenarios["متفائل"] = optimistic_predictions
        
        # السيناريو المتشائم (أعلى بنسبة 10%)
        pessimistic_predictions = [prediction * 1.1 for prediction in baseline_predictions]
        scenarios["متشائم"] = pessimistic_predictions
        
        return scenarios
