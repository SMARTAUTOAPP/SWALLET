from enum import Enum
from typing import List, Dict, Optional, Tuple
from collections import defaultdict

class RecommendationType(Enum):
    """
    أنواع التوصيات
    """
    REDUCE_SPENDING = "تقليل الإنفاق"
    BUDGET_ADJUSTMENT = "تعديل الميزانية"
    SAVING_CHALLENGE = "تحدي التوفير"
    INCOME_OPPORTUNITY = "فرصة زيادة الدخل"

class Recommendation:
    """
    فئة لتمثيل توصية ذكية
    """
    def __init__(self, type: RecommendationType, category: str, description: str, 
                potential_saving: float, confidence: float):
        self.type = type
        self.category = category
        self.description = description
        self.potential_saving = potential_saving
        self.confidence = confidence
    
    def to_dict(self) -> dict:
        """
        تحويل التوصية إلى قاموس
        """
        return {
            'type': self.type.value,
            'category': self.category,
            'description': self.description,
            'potential_saving': self.potential_saving,
            'confidence': self.confidence
        }

class SmartRecommendationEngine:
    """
    نظام التوصيات الذكية
    يقدم توصيات مخصصة لتوفير المال بناءً على أنماط الإنفاق
    """
    
    # عتبات للتوصيات
    HIGH_SPENDING_THRESHOLD = 0.2  # 20% فوق المتوسط
    SAVING_OPPORTUNITY_THRESHOLD = 0.15  # 15% من الإنفاق
    
    def __init__(self):
        pass
    
    def generate_recommendations(self, transactions: List[dict], budgets: List[dict]) -> List[Recommendation]:
        """
        تحليل المعاملات وإنشاء توصيات ذكية
        
        Args:
            transactions: قائمة المعاملات
            budgets: قائمة الميزانيات
            
        Returns:
            قائمة بالتوصيات الذكية
        """
        print("توليد التوصيات الذكية...")
        
        recommendations = []
        
        # تحليل أنماط الإنفاق حسب الفئة
        category_spending = self._analyze_category_spending(transactions)
        
        # تحليل الميزانيات مقابل الإنفاق الفعلي
        budget_utilization = self._analyze_budget_utilization(transactions, budgets)
        
        # 1. توصيات تقليل الإنفاق
        recommendations.extend(self._generate_reduce_spending_recommendations(category_spending))
        
        # 2. توصيات تعديل الميزانية
        recommendations.extend(self._generate_budget_adjustment_recommendations(budget_utilization))
        
        # 3. تحديات التوفير
        recommendations.extend(self._generate_saving_challenges(category_spending))
        
        # 4. فرص زيادة الدخل (مبسطة - في التطبيق الفعلي قد تحتاج إلى منطق أكثر تعقيداً)
        recommendations.append(Recommendation(
            RecommendationType.INCOME_OPPORTUNITY,
            "دخل",
            "فكر في مصادر دخل إضافية أو استثمارات لزيادة دخلك الشهري",
            0.0,
            0.7
        ))
        
        print(f"تم توليد {len(recommendations)} توصيات")
        
        return recommendations
    
    def _analyze_category_spending(self, transactions: List[dict]) -> Dict[str, List[float]]:
        """
        تحليل الإنفاق حسب الفئة
        
        Args:
            transactions: قائمة المعاملات
            
        Returns:
            خريطة تحتوي على قوائم الإنفاق لكل فئة
        """
        category_spending = defaultdict(list)
        
        for transaction in transactions:
            amount = float(transaction['amount'])
            if amount < 0:  # معاملات الإنفاق فقط (المبالغ السالبة)
                category = transaction['category']
                amount_abs = abs(amount)
                category_spending[category].append(amount_abs)
        
        return category_spending
    
    def _analyze_budget_utilization(self, transactions: List[dict], budgets: List[dict]) -> Dict[str, float]:
        """
        تحليل استخدام الميزانية
        
        Args:
            transactions: قائمة المعاملات
            budgets: قائمة الميزانيات
            
        Returns:
            خريطة تحتوي على نسبة استخدام الميزانية لكل فئة
        """
        budget_utilization = {}
        category_total_spending = defaultdict(float)
        category_budget_amount = {}
        
        # حساب إجمالي الإنفاق لكل فئة
        for transaction in transactions:
            amount = float(transaction['amount'])
            if amount < 0:  # معاملات الإنفاق فقط
                category = transaction['category']
                amount_abs = abs(amount)
                category_total_spending[category] += amount_abs
        
        # الحصول على مبلغ الميزانية لكل فئة
        for budget in budgets:
            category = budget['category']
            amount = float(budget['amount'])
            category_budget_amount[category] = amount
        
        # حساب نسبة استخدام الميزانية
        for category, total_spending in category_total_spending.items():
            if category in category_budget_amount and category_budget_amount[category] > 0:
                utilization = total_spending / category_budget_amount[category]
                budget_utilization[category] = utilization
        
        return budget_utilization
    
    def _generate_reduce_spending_recommendations(self, category_spending: Dict[str, List[float]]) -> List[Recommendation]:
        """
        توليد توصيات لتقليل الإنفاق
        
        Args:
            category_spending: خريطة الإنفاق حسب الفئة
            
        Returns:
            قائمة بالتوصيات
        """
        recommendations = []
        
        for category, spending in category_spending.items():
            if len(spending) < 2:
                continue  # نحتاج على الأقل إلى معاملتين للمقارنة
            
            # حساب متوسط الإنفاق
            total_spending = sum(spending)
            average_spending = total_spending / len(spending)
            
            # البحث عن معاملات أعلى من المتوسط بنسبة معينة
            high_spending_threshold = average_spending * (1 + self.HIGH_SPENDING_THRESHOLD)
            high_spending_count = sum(1 for amount in spending if amount > high_spending_threshold)
            
            # إذا كان هناك عدد كافٍ من معاملات الإنفاق العالي، قم بإنشاء توصية
            if high_spending_count >= 2 or (len(spending) >= 5 and high_spending_count >= 1):
                potential_saving = average_spending * self.SAVING_OPPORTUNITY_THRESHOLD * len(spending)
                confidence = min(0.9, 0.5 + (high_spending_count / len(spending)))
                
                recommendations.append(Recommendation(
                    RecommendationType.REDUCE_SPENDING,
                    category,
                    f"يمكنك توفير المال عن طريق تقليل الإنفاق في فئة {category} حيث أن إنفاقك أعلى من المتوسط",
                    potential_saving,
                    confidence
                ))
        
        return recommendations
    
    def _generate_budget_adjustment_recommendations(self, budget_utilization: Dict[str, float]) -> List[Recommendation]:
        """
        توليد توصيات لتعديل الميزانية
        
        Args:
            budget_utilization: خريطة استخدام الميزانية
            
        Returns:
            قائمة بالتوصيات
        """
        recommendations = []
        
        for category, utilization in budget_utilization.items():
            if utilization > 1.2:  # تجاوز الميزانية بنسبة 20% أو أكثر
                recommendations.append(Recommendation(
                    RecommendationType.BUDGET_ADJUSTMENT,
                    category,
                    f"ميزانيتك لفئة {category} غير كافية. فكر في زيادتها أو تقليل الإنفاق",
                    0.0,  # لا يوجد توفير مباشر
                    0.8
                ))
            elif utilization < 0.7:  # استخدام أقل من 70% من الميزانية
                recommendations.append(Recommendation(
                    RecommendationType.BUDGET_ADJUSTMENT,
                    category,
                    f"ميزانيتك لفئة {category} أعلى من احتياجاتك. يمكنك تخفيضها وتخصيص الفائض لفئات أخرى",
                    0.0,  # لا يوجد توفير مباشر
                    0.7
                ))
        
        return recommendations
    
    def _generate_saving_challenges(self, category_spending: Dict[str, List[float]]) -> List[Recommendation]:
        """
        توليد تحديات التوفير
        
        Args:
            category_spending: خريطة الإنفاق حسب الفئة
            
        Returns:
            قائمة بالتوصيات
        """
        recommendations = []
        
        # تحديد الفئات ذات الإنفاق الأعلى
        category_total_spending = {}
        overall_total_spending = 0.0
        
        for category, spending in category_spending.items():
            total_category_spending = sum(spending)
            category_total_spending[category] = total_category_spending
            overall_total_spending += total_category_spending
        
        # إنشاء تحديات للفئات التي تمثل نسبة كبيرة من الإنفاق
        for category, total_spending in category_total_spending.items():
            spending_percentage = total_spending / overall_total_spending if overall_total_spending > 0 else 0
            
            if spending_percentage > 0.15:  # الفئة تمثل أكثر من 15% من إجمالي الإنفاق
                challenge_target = total_spending * 0.1  # تحدي لتوفير 10%
                
                recommendations.append(Recommendation(
                    RecommendationType.SAVING_CHALLENGE,
                    category,
                    f"تحدي التوفير: حاول تقليل إنفاقك في فئة {category} بنسبة 10% هذا الشهر",
                    challenge_target,
                    0.75
                ))
        
        return recommendations
    
    def get_top_recommendations(self, recommendations: List[Recommendation], max_count: int) -> List[Recommendation]:
        """
        الحصول على أفضل التوصيات
        
        Args:
            recommendations: قائمة كاملة بالتوصيات
            max_count: الحد الأقصى لعدد التوصيات المطلوبة
            
        Returns:
            قائمة بأفضل التوصيات
        """
        # ترتيب التوصيات حسب الثقة والتوفير المحتمل
        sorted_recommendations = sorted(
            recommendations,
            key=lambda r: r.confidence * 0.7 + (0.3 if r.potential_saving > 0 else 0),
            reverse=True
        )
        
        # إرجاع أفضل N توصيات
        return sorted_recommendations[:min(max_count, len(sorted_recommendations))]
