import math
import re
from collections import defaultdict
from typing import List, Dict, Set, Tuple, Optional

class TransactionClassifier:
    """
    نموذج التصنيف التلقائي للمعاملات
    يستخدم خوارزمية Naive Bayes لتصنيف المعاملات بناءً على وصفها ومبلغها
    """
    
    def __init__(self):
        # خرائط لتخزين احتمالات الكلمات لكل فئة
        self.word_probabilities: Dict[str, Dict[str, float]] = {}
        # احتمالات الفئات المسبقة
        self.category_priors: Dict[str, float] = {}
        # مجموعة الكلمات المميزة
        self.vocabulary: Set[str] = set()
        # عدد المعاملات التدريبية
        self.total_transactions: int = 0
    
    def train(self, transactions: List[dict]) -> None:
        """
        تدريب النموذج باستخدام قائمة من المعاملات المصنفة مسبقاً
        
        Args:
            transactions: قائمة المعاملات التدريبية
        """
        print("بدء تدريب نموذج التصنيف التلقائي...")
        
        # إعادة تعيين النموذج
        self.word_probabilities = {}
        self.category_priors = {}
        self.vocabulary = set()
        self.total_transactions = len(transactions)
        
        # حساب عدد المعاملات لكل فئة
        category_counts: Dict[str, int] = defaultdict(int)
        word_counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        
        # المرور على جميع المعاملات لبناء المفردات وحساب التكرارات
        for transaction in transactions:
            category = transaction['category']
            description = transaction['description'].lower()
            
            # تحديث عدد المعاملات في الفئة
            category_counts[category] += 1
            
            # تقسيم الوصف إلى كلمات
            words = re.split(r'\s+', description)
            for word in words:
                # تنظيف الكلمة من الأحرف غير الأبجدية
                word = re.sub(r'[^\w\s]', '', word).strip()
                if not word:
                    continue
                
                # إضافة الكلمة إلى المفردات
                self.vocabulary.add(word)
                
                # تحديث عدد مرات ظهور الكلمة في الفئة
                word_counts[category][word] += 1
        
        # حساب الاحتمالات المسبقة للفئات
        for category, count in category_counts.items():
            self.category_priors[category] = count / self.total_transactions
        
        # حساب احتمالات الكلمات لكل فئة (مع تمهيد لابلاس)
        for category in category_counts:
            category_word_counts = word_counts[category]
            total_words_in_category = sum(category_word_counts.values())
            
            # إنشاء خريطة احتمالات الكلمات للفئة
            probabilities = {}
            
            # حساب احتمال كل كلمة في المفردات لهذه الفئة
            for word in self.vocabulary:
                word_count = category_word_counts.get(word, 0)
                # تطبيق تمهيد لابلاس (إضافة 1 لتجنب الاحتمالات الصفرية)
                probability = (word_count + 1.0) / (total_words_in_category + len(self.vocabulary))
                probabilities[word] = probability
            
            self.word_probabilities[category] = probabilities
        
        print(f"اكتمل تدريب النموذج. عدد الفئات: {len(category_counts)}, حجم المفردات: {len(self.vocabulary)}")
    
    def classify(self, description: str, amount: float) -> str:
        """
        تصنيف معاملة جديدة بناءً على وصفها
        
        Args:
            description: وصف المعاملة
            amount: مبلغ المعاملة
            
        Returns:
            الفئة المتوقعة للمعاملة
        """
        if not self.word_probabilities or not self.category_priors:
            print("لم يتم تدريب النموذج بعد!")
            return "غير مصنف"
        
        description = description.lower()
        words = re.split(r'\s+', description)
        
        best_category = None
        best_score = float('-inf')
        
        # حساب درجة كل فئة (لوغاريتم الاحتمال لتجنب مشكلة الأرقام الصغيرة جداً)
        for category in self.category_priors:
            score = math.log(self.category_priors[category])
            category_word_probs = self.word_probabilities[category]
            
            # إضافة لوغاريتم احتمال كل كلمة في الوصف
            for word in words:
                word = re.sub(r'[^\w\s]', '', word).strip()
                if not word:
                    continue
                
                # استخدام احتمال الكلمة إذا كانت موجودة في المفردات، وإلا استخدام قيمة افتراضية
                if word in self.vocabulary and word in category_word_probs:
                    score += math.log(category_word_probs[word])
            
            # تعديل الدرجة بناءً على المبلغ (يمكن تحسين هذا الجزء بناءً على البيانات الفعلية)
            # على سبيل المثال، قد تكون المبالغ الكبيرة أكثر احتمالاً لفئات معينة
            
            if score > best_score:
                best_score = score
                best_category = category
        
        return best_category if best_category is not None else "غير مصنف"
    
    def get_top_categories(self, description: str, amount: float, top_n: int = 3) -> List[Tuple[str, float]]:
        """
        الحصول على أفضل N فئات محتملة مع درجاتها
        
        Args:
            description: وصف المعاملة
            amount: مبلغ المعاملة
            top_n: عدد الفئات المطلوبة
            
        Returns:
            قائمة بأفضل N فئات محتملة مع درجاتها
        """
        if not self.word_probabilities or not self.category_priors:
            print("لم يتم تدريب النموذج بعد!")
            return []
        
        description = description.lower()
        words = re.split(r'\s+', description)
        
        scores = {}
        
        # حساب درجة كل فئة
        for category in self.category_priors:
            score = math.log(self.category_priors[category])
            category_word_probs = self.word_probabilities[category]
            
            for word in words:
                word = re.sub(r'[^\w\s]', '', word).strip()
                if not word:
                    continue
                
                if word in self.vocabulary and word in category_word_probs:
                    score += math.log(category_word_probs[word])
            
            # تحويل اللوغاريتم إلى احتمال
            scores[category] = score
        
        # ترتيب الفئات حسب الدرجة
        sorted_categories = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        
        # إرجاع أفضل N فئات
        return sorted_categories[:min(top_n, len(sorted_categories))]
    
    def update_model(self, transaction: dict) -> None:
        """
        تحديث النموذج بمعاملة جديدة (التعلم المستمر)
        
        Args:
            transaction: المعاملة الجديدة
        """
        # يمكن تنفيذ هذه الطريقة لتحديث النموذج تدريجياً بدلاً من إعادة التدريب الكامل
        # هذا يتطلب تحديث احتمالات الكلمات والفئات بناءً على المعاملة الجديدة
        
        # ملاحظة: هذه طريقة مبسطة، وفي التطبيق الفعلي قد تحتاج إلى منطق أكثر تعقيداً
        transactions = [transaction]
        # إعادة تدريب النموذج
        self.train(transactions)
