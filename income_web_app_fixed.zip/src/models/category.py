from datetime import datetime
from src.models import db

class Category(db.Model):
    """
    نموذج الفئة
    يمثل فئة للمعاملات المالية (مثل طعام، سكن، ترفيه، إلخ)
    """
    __tablename__ = 'categories'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    icon = db.Column(db.String(50), nullable=True)
    color = db.Column(db.String(20), nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    def __init__(self, name, user_id, icon=None, color=None):
        self.name = name
        self.user_id = user_id
        self.icon = icon
        self.color = color
    
    def to_dict(self):
        """
        تحويل الفئة إلى قاموس
        """
        return {
            'id': self.id,
            'name': self.name,
            'icon': self.icon,
            'color': self.color,
            'user_id': self.user_id
        }
