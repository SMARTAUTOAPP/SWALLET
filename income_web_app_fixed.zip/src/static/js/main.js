// تطبيق إدارة الدخل الذكي - الوظائف الرئيسية للجافاسكريبت

document.addEventListener('DOMContentLoaded', function() {
    // تبديل الوضع المظلم
    const darkModeSwitch = document.getElementById('darkModeSwitch');
    if (darkModeSwitch) {
        // التحقق من حالة الوضع المظلم المخزنة
        const isDarkMode = localStorage.getItem('darkMode') === 'true';
        darkModeSwitch.checked = isDarkMode;
        
        // تطبيق الوضع المظلم إذا كان مفعلاً
        if (isDarkMode) {
            document.body.classList.add('dark-mode');
            loadDarkThemeStylesheet();
        }
        
        // تبديل الوضع المظلم عند النقر على المفتاح
        darkModeSwitch.addEventListener('change', function() {
            if (this.checked) {
                document.body.classList.add('dark-mode');
                localStorage.setItem('darkMode', 'true');
                loadDarkThemeStylesheet();
            } else {
                document.body.classList.remove('dark-mode');
                localStorage.setItem('darkMode', 'false');
                unloadDarkThemeStylesheet();
            }
        });
    }
    
    // تحميل ملف الأنماط المظلمة
    function loadDarkThemeStylesheet() {
        if (!document.getElementById('dark-theme-css')) {
            const link = document.createElement('link');
            link.id = 'dark-theme-css';
            link.rel = 'stylesheet';
            link.href = '/static/css/dark-theme.css';
            document.head.appendChild(link);
        }
    }
    
    // إزالة ملف الأنماط المظلمة
    function unloadDarkThemeStylesheet() {
        const darkThemeLink = document.getElementById('dark-theme-css');
        if (darkThemeLink) {
            darkThemeLink.remove();
        }
    }
    
    // تنسيق الأرقام المالية
    function formatCurrency(amount) {
        return new Intl.NumberFormat('ar-SA', {
            style: 'currency',
            currency: 'SAR',
            minimumFractionDigits: 2
        }).format(amount);
    }
    
    // تنسيق التواريخ
    function formatDate(dateString) {
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('ar-SA', options);
    }
    
    // تحديث التواريخ المعروضة
    const dateElements = document.querySelectorAll('.format-date');
    dateElements.forEach(function(element) {
        const dateString = element.getAttribute('data-date');
        if (dateString) {
            element.textContent = formatDate(dateString);
        }
    });
    
    // تحديث المبالغ المالية المعروضة
    const amountElements = document.querySelectorAll('.format-amount');
    amountElements.forEach(function(element) {
        const amount = parseFloat(element.getAttribute('data-amount'));
        if (!isNaN(amount)) {
            element.textContent = formatCurrency(amount);
        }
    });
    
    // تفعيل التلميحات
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // إخفاء رسائل التنبيه بعد فترة
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
    
    // تفعيل التحقق من صحة النماذج
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
    
    // تفعيل الرسوم البيانية (إذا كانت موجودة في الصفحة)
    initializeCharts();
    
    // تفعيل التصنيف الذكي للمعاملات
    initializeSmartClassification();
    
    // تفعيل التوصيات الذكية
    initializeSmartRecommendations();
    
    // تفعيل المساعد الذكي للميزانية
    initializeSmartBudgetAssistant();
});

// تهيئة الرسوم البيانية
function initializeCharts() {
    // التحقق من وجود عنصر الرسم البياني للنظرة العامة
    const overviewChartElement = document.getElementById('overviewChart');
    if (overviewChartElement) {
        // هنا يتم تهيئة الرسم البياني للنظرة العامة
        // سيتم استبدال هذا بالبيانات الفعلية من الخادم
    }
    
    // التحقق من وجود عنصر الرسم البياني لتوزيع المصروفات
    const expensesCategoryChartElement = document.getElementById('expensesCategoryChart');
    if (expensesCategoryChartElement) {
        // هنا يتم تهيئة الرسم البياني لتوزيع المصروفات
        // سيتم استبدال هذا بالبيانات الفعلية من الخادم
    }
    
    // التحقق من وجود عنصر الرسم البياني للتنبؤات المالية
    const predictionsChartElement = document.getElementById('predictionsChart');
    if (predictionsChartElement) {
        // هنا يتم تهيئة الرسم البياني للتنبؤات المالية
        // سيتم استبدال هذا بالبيانات الفعلية من الخادم
    }
}

// تهيئة التصنيف الذكي للمعاملات
function initializeSmartClassification() {
    const classifyBtn = document.getElementById('smart-classify-btn');
    if (classifyBtn) {
        classifyBtn.addEventListener('click', function() {
            const description = document.getElementById('description').value.trim();
            const amount = parseFloat(document.getElementById('amount').value) || 0;
            
            if (!description) {
                alert('الرجاء إدخال وصف للمعاملة');
                return;
            }
            
            // إظهار مؤشر التحميل
            classifyBtn.disabled = true;
            classifyBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> جاري التصنيف...';
            
            // استدعاء واجهة برمجة التطبيقات للتصنيف
            fetch('/api/classify-transaction', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    description: description,
                    amount: amount
                }),
            })
            .then(response => response.json())
            .then(data => {
                // عرض النتيجة
                const resultDiv = document.getElementById('classification-result');
                const suggestedCategory = document.getElementById('suggested-category');
                const otherCategories = document.getElementById('other-categories');
                
                suggestedCategory.textContent = data.category;
                
                // تحديث قيمة الفئة في النموذج
                const categorySelect = document.getElementById('category');
                for (let i = 0; i < categorySelect.options.length; i++) {
                    if (categorySelect.options[i].value === data.category) {
                        categorySelect.selectedIndex = i;
                        break;
                    }
                }
                
                // عرض الفئات الأخرى المحتملة
                otherCategories.innerHTML = '';
                if (data.top_categories && data.top_categories.length > 0) {
                    data.top_categories.forEach(category => {
                        if (category !== data.category) {
                            const li = document.createElement('li');
                            li.textContent = category;
                            li.style.cursor = 'pointer';
                            li.style.color = '#0d6efd';
                            li.addEventListener('click', function() {
                                for (let i = 0; i < categorySelect.options.length; i++) {
                                    if (categorySelect.options[i].value === category) {
                                        categorySelect.selectedIndex = i;
                                        break;
                                    }
                                }
                            });
                            otherCategories.appendChild(li);
                        }
                    });
                }
                
                resultDiv.style.display = 'block';
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ أثناء التصنيف. الرجاء المحاولة مرة أخرى.');
            })
            .finally(() => {
                // إعادة تفعيل الزر
                classifyBtn.disabled = false;
                classifyBtn.innerHTML = '<i class="bi bi-magic"></i> تصنيف ذكي';
            });
        });
    }
}

// تهيئة التوصيات الذكية
function initializeSmartRecommendations() {
    const recommendationsContainer = document.getElementById('smart-recommendations');
    if (recommendationsContainer) {
        // استدعاء واجهة برمجة التطبيقات للحصول على التوصيات
        fetch('/api/get-recommendations')
            .then(response => response.json())
            .then(data => {
                if (data.recommendations && data.recommendations.length > 0) {
                    recommendationsContainer.innerHTML = '';
                    
                    data.recommendations.forEach(recommendation => {
                        const card = document.createElement('div');
                        card.className = 'card border-0 shadow-sm mb-3 smart-recommendation';
                        
                        card.innerHTML = `
                            <div class="card-body">
                                <h5 class="card-title">
                                    <i class="bi ${recommendation.icon} text-primary me-2"></i> ${recommendation.title}
                                </h5>
                                <p class="text-muted">${recommendation.description}</p>
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="badge bg-${recommendation.type === 'saving' ? 'success' : 'info'}">${recommendation.type === 'saving' ? 'توفير' : 'معلومة'}</span>
                                    <small class="text-muted">${formatDate(recommendation.date)}</small>
                                </div>
                            </div>
                        `;
                        
                        recommendationsContainer.appendChild(card);
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
}

// تهيئة المساعد الذكي للميزانية
function initializeSmartBudgetAssistant() {
    const generateSmartBudgetsBtn = document.getElementById('generate-smart-budgets-btn');
    if (generateSmartBudgetsBtn) {
        generateSmartBudgetsBtn.addEventListener('click', function() {
            // إظهار مؤشر التحميل
            generateSmartBudgetsBtn.disabled = true;
            generateSmartBudgetsBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> جاري التحليل...';
            
            // استدعاء واجهة برمجة التطبيقات للحصول على الميزانيات الذكية
            fetch('/api/generate-smart-budgets')
                .then(response => response.json())
                .then(data => {
                    const smartBudgetsResult = document.getElementById('smart-budgets-result');
                    if (smartBudgetsResult) {
                        smartBudgetsResult.style.display = 'block';
                        
                        // التمرير إلى النتائج
                        smartBudgetsResult.scrollIntoView({ behavior: 'smooth' });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('حدث خطأ أثناء توليد الميزانيات الذكية. الرجاء المحاولة مرة أخرى.');
                })
                .finally(() => {
                    // إعادة تفعيل الزر
                    generateSmartBudgetsBtn.disabled = false;
                    generateSmartBudgetsBtn.innerHTML = '<i class="bi bi-magic"></i> توليد ميزانيات ذكية';
                });
        });
    }
}

// تنسيق التاريخ
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('ar-SA', options);
}

// تنسيق المبلغ المالي
function formatCurrency(amount) {
    return new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: 'SAR',
        minimumFractionDigits: 2
    }).format(amount);
}
