# دليل التثبيت والتشغيل - تطبيق إدارة الدخل الذكي (نسخة الويب)

## المتطلبات الأساسية

قبل البدء في تثبيت وتشغيل تطبيق إدارة الدخل الذكي، تأكد من توفر المتطلبات التالية:

### متطلبات النظام
- نظام تشغيل: Linux (Ubuntu 20.04 أو أحدث مفضل)، Windows 10 أو أحدث، macOS 10.15 أو أحدث
- ذاكرة وصول عشوائي (RAM): 4 جيجابايت على الأقل، 8 جيجابايت مفضل
- مساحة تخزين: 2 جيجابايت على الأقل من المساحة الحرة

### البرمجيات المطلوبة
- Python 3.8 أو أحدث
- pip (مدير حزم Python)
- قاعدة بيانات MySQL 5.7 أو أحدث (أو SQLite للاستخدام المحلي)
- خادم ويب (Apache أو Nginx) للنشر في بيئة الإنتاج

## خطوات التثبيت

### 1. تحضير البيئة

#### تثبيت Python ومدير الحزم pip

**على نظام Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv
```

**على نظام Windows:**
- قم بتنزيل وتثبيت Python من [الموقع الرسمي](https://www.python.org/downloads/)
- تأكد من تفعيل خيار "Add Python to PATH" أثناء التثبيت

**على نظام macOS:**
```bash
brew install python3
```

#### تثبيت قاعدة البيانات MySQL (اختياري، يمكن استخدام SQLite للبيئة المحلية)

**على نظام Ubuntu/Debian:**
```bash
sudo apt install mysql-server
sudo mysql_secure_installation
```

**على نظام Windows:**
- قم بتنزيل وتثبيت MySQL من [الموقع الرسمي](https://dev.mysql.com/downloads/installer/)

**على نظام macOS:**
```bash
brew install mysql
brew services start mysql
```

### 2. تنزيل التطبيق

1. قم بتنزيل حزمة التطبيق من الرابط المقدم أو استنساخ المستودع:
```bash
git clone https://github.com/yourusername/income_web_app.git
cd income_web_app_new
```

### 3. إعداد البيئة الافتراضية

إنشاء وتفعيل بيئة افتراضية لعزل تبعيات التطبيق:

**على نظام Linux/macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**على نظام Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

### 4. تثبيت التبعيات

تثبيت جميع المكتبات والحزم المطلوبة:
```bash
pip install -r requirements.txt
```

### 5. تكوين التطبيق

1. انسخ ملف التكوين النموذجي:
```bash
cp .env.example .env
```

2. قم بتعديل ملف `.env` لتكوين إعدادات التطبيق:
```
# إعدادات التطبيق
SECRET_KEY=your_secret_key_here
DEBUG=True  # اضبط على False في بيئة الإنتاج

# إعدادات قاعدة البيانات
DB_TYPE=mysql  # استخدم sqlite للتطوير المحلي
DB_USERNAME=root
DB_PASSWORD=your_password
DB_HOST=localhost
DB_PORT=3306
DB_NAME=income_manager

# إعدادات البريد الإلكتروني (اختياري)
MAIL_SERVER=smtp.example.com
MAIL_PORT=587
MAIL_USERNAME=your_email@example.com
MAIL_PASSWORD=your_email_password
MAIL_USE_TLS=True
```

### 6. إعداد قاعدة البيانات

1. إنشاء قاعدة البيانات:

**باستخدام MySQL:**
```bash
mysql -u root -p
```

```sql
CREATE DATABASE income_manager CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'income_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON income_manager.* TO 'income_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

2. تهيئة قاعدة البيانات:
```bash
python src/init_db.py
```

### 7. تشغيل التطبيق للتطوير

لتشغيل التطبيق في بيئة التطوير:
```bash
python src/main.py
```

سيتم تشغيل التطبيق على المنفذ 5000 بشكل افتراضي. يمكنك الوصول إليه عبر المتصفح على العنوان:
```
http://localhost:5000
```

## نشر التطبيق في بيئة الإنتاج

### 1. إعداد خادم الويب

#### باستخدام Nginx و Gunicorn

1. تثبيت Nginx و Gunicorn:
```bash
sudo apt install nginx
pip install gunicorn
```

2. إنشاء ملف تكوين Nginx:
```bash
sudo nano /etc/nginx/sites-available/income_manager
```

3. أضف التكوين التالي:
```
server {
    listen 80;
    server_name your_domain.com www.your_domain.com;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /static {
        alias /path/to/income_web_app_new/src/static;
    }
}
```

4. تفعيل الموقع:
```bash
sudo ln -s /etc/nginx/sites-available/income_manager /etc/nginx/sites-enabled
sudo nginx -t
sudo systemctl restart nginx
```

5. إنشاء ملف خدمة systemd:
```bash
sudo nano /etc/systemd/system/income_manager.service
```

6. أضف التكوين التالي:
```
[Unit]
Description=Income Manager Web Application
After=network.target

[Service]
User=your_username
Group=www-data
WorkingDirectory=/path/to/income_web_app_new
Environment="PATH=/path/to/income_web_app_new/venv/bin"
ExecStart=/path/to/income_web_app_new/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:8000 -m 007 'src.main:app'

[Install]
WantedBy=multi-user.target
```

7. تفعيل وتشغيل الخدمة:
```bash
sudo systemctl enable income_manager
sudo systemctl start income_manager
```

### 2. إعداد HTTPS (مستحسن)

لتأمين التطبيق باستخدام HTTPS، يمكنك استخدام Let's Encrypt:

1. تثبيت Certbot:
```bash
sudo apt install certbot python3-certbot-nginx
```

2. الحصول على شهادة SSL:
```bash
sudo certbot --nginx -d your_domain.com -d www.your_domain.com
```

3. اتبع التعليمات لإكمال الإعداد.

## إدارة التطبيق

### تحديث التطبيق

لتحديث التطبيق إلى أحدث إصدار:

1. انتقل إلى مجلد التطبيق:
```bash
cd /path/to/income_web_app_new
```

2. قم بتحديث الكود المصدري:
```bash
git pull origin main
```

3. قم بتحديث البيئة الافتراضية:
```bash
source venv/bin/activate
pip install -r requirements.txt
```

4. قم بتحديث قاعدة البيانات (إذا لزم الأمر):
```bash
python src/update_db.py
```

5. أعد تشغيل الخدمة:
```bash
sudo systemctl restart income_manager
```

### النسخ الاحتياطي

من المهم إجراء نسخ احتياطي منتظم لقاعدة البيانات:

1. نسخ احتياطي لقاعدة البيانات:
```bash
mysqldump -u income_user -p income_manager > backup_$(date +%Y%m%d).sql
```

2. يمكنك جدولة هذه العملية باستخدام cron:
```bash
crontab -e
```

3. أضف السطر التالي لإجراء نسخ احتياطي يومي:
```
0 2 * * * mysqldump -u income_user -p'your_password' income_manager > /path/to/backups/backup_$(date +\%Y\%m\%d).sql
```

## استكشاف الأخطاء وإصلاحها

### مشكلة: التطبيق لا يعمل بعد التثبيت

**الحل المحتمل:**
1. تحقق من تنشيط البيئة الافتراضية:
```bash
source venv/bin/activate
```

2. تحقق من تثبيت جميع التبعيات:
```bash
pip install -r requirements.txt
```

3. تحقق من إعدادات قاعدة البيانات في ملف `.env`

### مشكلة: خطأ في الاتصال بقاعدة البيانات

**الحل المحتمل:**
1. تأكد من تشغيل خدمة MySQL:
```bash
sudo systemctl status mysql
```

2. تحقق من صحة بيانات الاتصال في ملف `.env`

3. تأكد من وجود قاعدة البيانات والمستخدم:
```bash
mysql -u root -p
```
```sql
SHOW DATABASES;
SELECT User FROM mysql.user;
```

### مشكلة: الصفحات لا تعرض بشكل صحيح

**الحل المحتمل:**
1. تحقق من ملفات CSS و JavaScript:
```bash
ls -la src/static/css
ls -la src/static/js
```

2. تأكد من تكوين Nginx بشكل صحيح لخدمة الملفات الثابتة

## الدعم الفني

إذا واجهتك أي مشكلة أثناء التثبيت أو التشغيل، يمكنك:

1. مراجعة وثائق API في `docs/api_documentation.md`
2. التواصل مع فريق الدعم الفني عبر البريد الإلكتروني: support@smartincome.com

## الترخيص

تطبيق إدارة الدخل الذكي مرخص بموجب رخصة MIT. يرجى مراجعة ملف `LICENSE` للحصول على مزيد من المعلومات.
