# توثيق واجهة برمجة التطبيقات (API) - تطبيق إدارة الدخل الذكي

## مقدمة

هذا المستند يوثق واجهة برمجة التطبيقات (API) الخاصة بتطبيق إدارة الدخل الذكي. يمكن استخدام هذه الواجهات للتفاعل مع الميزات الذكية للتطبيق وإدارة البيانات المالية.

## معلومات عامة

- **نقطة الوصول الأساسية**: `/api/v1`
- **تنسيق البيانات**: JSON
- **المصادقة**: JWT (JSON Web Token)
- **ترميز الاستجابة**: UTF-8

## المصادقة

### الحصول على رمز الوصول (JWT)

**طلب**:
```
POST /api/v1/auth/login
```

**محتوى الطلب**:
```json
{
  "email": "user@example.com",
  "password": "your_password"
}
```

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 123,
    "name": "اسم المستخدم",
    "email": "user@example.com"
  }
}
```

**استجابة خاطئة (401 Unauthorized)**:
```json
{
  "status": "error",
  "message": "بيانات الاعتماد غير صحيحة"
}
```

### استخدام رمز الوصول

يجب تضمين رمز الوصول في ترويسة `Authorization` لجميع الطلبات التي تتطلب مصادقة:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

## واجهات برمجة المعاملات

### الحصول على قائمة المعاملات

**طلب**:
```
GET /api/v1/transactions
```

**معلمات الاستعلام الاختيارية**:
- `page`: رقم الصفحة (افتراضي: 1)
- `limit`: عدد العناصر في الصفحة (افتراضي: 20)
- `start_date`: تاريخ البداية (YYYY-MM-DD)
- `end_date`: تاريخ النهاية (YYYY-MM-DD)
- `type`: نوع المعاملة (income, expense)
- `category`: معرف الفئة

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "transactions": [
      {
        "id": 1,
        "amount": 5000,
        "description": "راتب شهر مايو",
        "type": "income",
        "category": "راتب",
        "date": "2025-05-01",
        "created_at": "2025-05-01T10:30:00Z"
      },
      {
        "id": 2,
        "amount": 150,
        "description": "فاتورة الكهرباء",
        "type": "expense",
        "category": "مرافق",
        "date": "2025-05-05",
        "created_at": "2025-05-05T14:20:00Z"
      }
    ],
    "pagination": {
      "total": 45,
      "pages": 3,
      "current_page": 1,
      "limit": 20
    }
  }
}
```

### إضافة معاملة جديدة

**طلب**:
```
POST /api/v1/transactions
```

**محتوى الطلب**:
```json
{
  "amount": 1000,
  "description": "مكافأة إضافية",
  "type": "income",
  "category": "دخل إضافي",
  "date": "2025-05-15"
}
```

**استجابة ناجحة (201 Created)**:
```json
{
  "status": "success",
  "data": {
    "transaction": {
      "id": 3,
      "amount": 1000,
      "description": "مكافأة إضافية",
      "type": "income",
      "category": "دخل إضافي",
      "date": "2025-05-15",
      "created_at": "2025-05-16T09:45:00Z"
    }
  }
}
```

### الحصول على معاملة محددة

**طلب**:
```
GET /api/v1/transactions/{id}
```

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "transaction": {
      "id": 1,
      "amount": 5000,
      "description": "راتب شهر مايو",
      "type": "income",
      "category": "راتب",
      "date": "2025-05-01",
      "created_at": "2025-05-01T10:30:00Z"
    }
  }
}
```

### تحديث معاملة

**طلب**:
```
PUT /api/v1/transactions/{id}
```

**محتوى الطلب**:
```json
{
  "amount": 5500,
  "description": "راتب شهر مايو مع العلاوة",
  "type": "income",
  "category": "راتب",
  "date": "2025-05-01"
}
```

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "transaction": {
      "id": 1,
      "amount": 5500,
      "description": "راتب شهر مايو مع العلاوة",
      "type": "income",
      "category": "راتب",
      "date": "2025-05-01",
      "updated_at": "2025-05-16T11:20:00Z"
    }
  }
}
```

### حذف معاملة

**طلب**:
```
DELETE /api/v1/transactions/{id}
```

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "message": "تم حذف المعاملة بنجاح"
}
```

## واجهات برمجة الفئات

### الحصول على قائمة الفئات

**طلب**:
```
GET /api/v1/categories
```

**معلمات الاستعلام الاختيارية**:
- `type`: نوع الفئة (income, expense)

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "categories": [
      {
        "id": 1,
        "name": "راتب",
        "type": "income",
        "icon": "wallet",
        "color": "#4CAF50"
      },
      {
        "id": 2,
        "name": "مرافق",
        "type": "expense",
        "icon": "flash",
        "color": "#F44336"
      }
    ]
  }
}
```

### إضافة فئة جديدة

**طلب**:
```
POST /api/v1/categories
```

**محتوى الطلب**:
```json
{
  "name": "استثمارات",
  "type": "income",
  "icon": "trending_up",
  "color": "#9C27B0"
}
```

**استجابة ناجحة (201 Created)**:
```json
{
  "status": "success",
  "data": {
    "category": {
      "id": 3,
      "name": "استثمارات",
      "type": "income",
      "icon": "trending_up",
      "color": "#9C27B0"
    }
  }
}
```

## واجهات برمجة الميزانيات

### الحصول على قائمة الميزانيات

**طلب**:
```
GET /api/v1/budgets
```

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "budgets": [
      {
        "id": 1,
        "category_id": 2,
        "category_name": "مرافق",
        "amount": 500,
        "spent": 150,
        "remaining": 350,
        "period": "monthly",
        "start_date": "2025-05-01",
        "end_date": "2025-05-31"
      },
      {
        "id": 2,
        "category_id": 4,
        "category_name": "طعام",
        "amount": 1200,
        "spent": 800,
        "remaining": 400,
        "period": "monthly",
        "start_date": "2025-05-01",
        "end_date": "2025-05-31"
      }
    ]
  }
}
```

### إنشاء ميزانية جديدة

**طلب**:
```
POST /api/v1/budgets
```

**محتوى الطلب**:
```json
{
  "category_id": 5,
  "amount": 300,
  "period": "monthly",
  "start_date": "2025-05-01"
}
```

**استجابة ناجحة (201 Created)**:
```json
{
  "status": "success",
  "data": {
    "budget": {
      "id": 3,
      "category_id": 5,
      "category_name": "ترفيه",
      "amount": 300,
      "spent": 0,
      "remaining": 300,
      "period": "monthly",
      "start_date": "2025-05-01",
      "end_date": "2025-05-31"
    }
  }
}
```

## واجهات برمجة الميزات الذكية

### التصنيف التلقائي للمعاملات

**طلب**:
```
POST /api/v1/classify-transaction
```

**محتوى الطلب**:
```json
{
  "description": "فاتورة Netflix الشهرية",
  "amount": 45
}
```

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "category": "ترفيه",
    "confidence": 0.85,
    "top_categories": [
      "ترفيه",
      "اشتراكات",
      "تكنولوجيا"
    ]
  }
}
```

### الحصول على التنبؤات المالية

**طلب**:
```
GET /api/v1/financial-predictions
```

**معلمات الاستعلام الاختيارية**:
- `months`: عدد الأشهر للتنبؤ (افتراضي: 3)
- `scenario`: نوع السيناريو (optimistic, expected, pessimistic)

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "predictions": [
      {
        "month": "2025-06",
        "income": {
          "expected": 5500,
          "optimistic": 6000,
          "pessimistic": 5000
        },
        "expenses": {
          "expected": 4200,
          "optimistic": 3800,
          "pessimistic": 4500
        },
        "savings": {
          "expected": 1300,
          "optimistic": 2200,
          "pessimistic": 500
        }
      },
      {
        "month": "2025-07",
        "income": {
          "expected": 5500,
          "optimistic": 6200,
          "pessimistic": 5000
        },
        "expenses": {
          "expected": 4300,
          "optimistic": 3900,
          "pessimistic": 4600
        },
        "savings": {
          "expected": 1200,
          "optimistic": 2300,
          "pessimistic": 400
        }
      }
    ],
    "confidence": 0.8
  }
}
```

### الحصول على التوصيات الذكية

**طلب**:
```
GET /api/v1/get-recommendations
```

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "recommendations": [
      {
        "id": 1,
        "title": "فرصة لتوفير المال في فئة المطاعم",
        "description": "لاحظنا أنك تنفق 30% أكثر من المتوسط على المطاعم. يمكنك توفير 450 ر.س شهرياً بتقليل الزيارات الأسبوعية بنسبة 20%.",
        "type": "saving",
        "icon": "restaurant",
        "date": "2025-05-15T00:00:00Z",
        "potential_saving": 450
      },
      {
        "id": 2,
        "title": "اشتراكات غير مستخدمة",
        "description": "وجدنا أنك تدفع 35 ر.س شهرياً لخدمة بث لم تستخدمها منذ 3 أشهر. يمكنك توفير 420 ر.س سنوياً بإلغاء هذا الاشتراك.",
        "type": "saving",
        "icon": "subscriptions",
        "date": "2025-05-16T00:00:00Z",
        "potential_saving": 35
      }
    ]
  }
}
```

### توليد ميزانيات ذكية

**طلب**:
```
POST /api/v1/generate-smart-budgets
```

**محتوى الطلب (اختياري)**:
```json
{
  "total_budget": 4000,
  "exclude_categories": [1, 3]
}
```

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "budgets": [
      {
        "category_id": 2,
        "category_name": "مرافق",
        "amount": 500,
        "percentage": 12.5,
        "rationale": "بناءً على متوسط إنفاقك البالغ 450 ر.س مع هامش 10% للتضخم"
      },
      {
        "category_id": 4,
        "category_name": "طعام",
        "amount": 1200,
        "percentage": 30,
        "rationale": "بناءً على متوسط إنفاقك البالغ 1150 ر.س مع تعديل موسمي"
      },
      {
        "category_id": 5,
        "category_name": "ترفيه",
        "amount": 300,
        "percentage": 7.5,
        "rationale": "اقتراح لتقليل الإنفاق بنسبة 15% عن المتوسط السابق البالغ 350 ر.س"
      }
    ],
    "total": 4000,
    "unallocated": 0
  }
}
```

## واجهات برمجة التقارير

### الحصول على ملخص مالي

**طلب**:
```
GET /api/v1/reports/summary
```

**معلمات الاستعلام الاختيارية**:
- `period`: الفترة الزمنية (month, quarter, year)
- `date`: تاريخ نهاية الفترة (YYYY-MM-DD)

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "period": "month",
    "start_date": "2025-05-01",
    "end_date": "2025-05-31",
    "income": {
      "total": 6500,
      "by_category": [
        {
          "category": "راتب",
          "amount": 5500,
          "percentage": 84.6
        },
        {
          "category": "دخل إضافي",
          "amount": 1000,
          "percentage": 15.4
        }
      ]
    },
    "expenses": {
      "total": 3200,
      "by_category": [
        {
          "category": "طعام",
          "amount": 1200,
          "percentage": 37.5
        },
        {
          "category": "مرافق",
          "amount": 500,
          "percentage": 15.6
        },
        {
          "category": "ترفيه",
          "amount": 300,
          "percentage": 9.4
        },
        {
          "category": "أخرى",
          "amount": 1200,
          "percentage": 37.5
        }
      ]
    },
    "savings": 3300,
    "savings_rate": 50.8
  }
}
```

### الحصول على تقرير الاتجاهات

**طلب**:
```
GET /api/v1/reports/trends
```

**معلمات الاستعلام الاختيارية**:
- `period`: الفترة الزمنية (day, week, month)
- `start_date`: تاريخ البداية (YYYY-MM-DD)
- `end_date`: تاريخ النهاية (YYYY-MM-DD)
- `category_id`: معرف الفئة للتصفية

**استجابة ناجحة (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "trends": [
      {
        "date": "2025-01",
        "income": 5000,
        "expenses": 3800,
        "savings": 1200
      },
      {
        "date": "2025-02",
        "income": 5000,
        "expenses": 3900,
        "savings": 1100
      },
      {
        "date": "2025-03",
        "income": 5200,
        "expenses": 4000,
        "savings": 1200
      },
      {
        "date": "2025-04",
        "income": 5200,
        "expenses": 4100,
        "savings": 1100
      },
      {
        "date": "2025-05",
        "income": 6500,
        "expenses": 3200,
        "savings": 3300
      }
    ]
  }
}
```

## رموز الحالة والأخطاء

### رموز الحالة

- `200 OK`: تم تنفيذ الطلب بنجاح
- `201 Created`: تم إنشاء المورد بنجاح
- `400 Bad Request`: طلب غير صالح
- `401 Unauthorized`: المصادقة مطلوبة
- `403 Forbidden`: ليس لديك صلاحية للوصول
- `404 Not Found`: المورد غير موجود
- `422 Unprocessable Entity`: بيانات غير صالحة
- `500 Internal Server Error`: خطأ في الخادم

### أمثلة على رسائل الخطأ

**خطأ في المصادقة (401 Unauthorized)**:
```json
{
  "status": "error",
  "message": "غير مصرح بالوصول. الرجاء تسجيل الدخول."
}
```

**خطأ في التحقق من صحة البيانات (422 Unprocessable Entity)**:
```json
{
  "status": "error",
  "message": "بيانات غير صالحة",
  "errors": {
    "amount": ["المبلغ مطلوب ويجب أن يكون رقماً موجباً"],
    "date": ["التاريخ مطلوب وبتنسيق صحيح (YYYY-MM-DD)"]
  }
}
```

**مورد غير موجود (404 Not Found)**:
```json
{
  "status": "error",
  "message": "المعاملة غير موجودة"
}
```

## الحدود والقيود

- **معدل الطلبات**: 100 طلب في الدقيقة لكل مستخدم
- **حجم الاستجابة**: الحد الأقصى 1 ميجابايت
- **حجم الطلب**: الحد الأقصى 10 ميجابايت
- **عدد المعاملات في الصفحة**: الحد الأقصى 100

## الإصدارات والتحديثات

- **الإصدار الحالي**: v1
- **تاريخ آخر تحديث**: 23 مايو 2025

للحصول على أحدث المعلومات والتحديثات، يرجى زيارة بوابة المطورين على:
https://developer.smartincome.com
